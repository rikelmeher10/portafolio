<?php
require "conexion.php";
$mensaje = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $correo = $mysqli->real_escape_string($_POST['correo']);
    $nueva_password = $_POST['password'];

    if (!preg_match("/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/", $nueva_password)) {
        $mensaje = "password_insegura";
    } else {
        $password_hash = sha1($nueva_password);
        $sql = "UPDATE usuarios SET password = '$password_hash' WHERE correo = '$correo'";

        if ($mysqli->query($sql) === TRUE) {
            $mensaje = "exito";
        } else {
            $mensaje = "error";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Restablecer Contraseña</title>
    <link rel="stylesheet" href="styles.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">

    <style>
        body {
            font-family: Arial, sans-serif;
        }

        .wrapper {
            max-width: 400px;
			height: 325px;
            margin: 60px auto;
            padding: 20px;
            border-radius: 10px;
            background: #f9f9f9;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

       .title-small {
            font-size: 20px;
            text-align: center;
            margin-bottom: 20px;
            color: #fff;
            background-color: #0a0a23; /* Mismo color que el login */
            padding: 10px;
            border-radius: 10px;
            display: inline-block;
            width: 100%;
        }

        .field1 {
            position: relative;
            display: flex;
            align-items: center;
            border: 1px solid #ccc;
            border-radius: 20px;
            padding: 10px;
            width: 100%;
            margin-bottom: 15px;
        }

        .field1 i {
            font-size: 16px;
            color: gray;
            margin-left: 10px;
        }

        .field1 input {
            border: none;
            outline: none;
            padding-left: 15px;
            font-size: 16px;
            width: 100%;
            background: transparent;
        }

        .eye-icon {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
        }

        .field input[type="submit"] {
            width: 100%;
            padding: 10px;
            background-color: #0a0a23;
            color: white;
            border: none;
            border-radius: 20px;
            cursor: pointer;
            font-size: 16px;
        }

        .signup-link {
            text-align: center;
            margin-top: 15px;
        }

        .signup-link a {
            color: #0a0a23;
            text-decoration: none;
        }
    </style>
</head>
<body>
    <div class="wrapper">
	<h2 class="title-small"><i class="fas fa-key"></i> Restablecer Contraseña</h2>
        <form method="POST">
            <input type="hidden" name="correo" value="<?php echo htmlspecialchars($_GET['correo'] ?? ''); ?>">
            <div class="field1">
                <i class="fas fa-lock"></i>
                <input type="password" name="password" id="password" placeholder="Nueva Contraseña" required>
                <span class="eye-icon" id="togglePassword">👁️</span>
            </div>
            <div class="field">
                <input type="submit" value="Cambiar Contraseña">
            </div>
            <div class="signup-link">
                <a href="login.php">Volver al login</a>
            </div>
        </form>
    </div>

<?php if ($mensaje === "exito"): ?>
    <script>
        Swal.fire({
            icon: 'success',
            title: 'Contraseña actualizada',
            text: 'Tu contraseña se ha actualizado correctamente',
            confirmButtonText: 'Aceptar',
            confirmButtonColor: '#3085d6'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = 'login.php';
            }
        });
    </script>


    <?php elseif ($mensaje === "error"): ?>
        <script>
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'Hubo un problema al actualizar la contraseña.'
            });
        </script>
    <?php elseif ($mensaje === "password_insegura"): ?>
        <script>
            Swal.fire({
                icon: 'warning',
                title: 'Contraseña insegura',
                html: 'Debe contener al menos 8 caracteres,<br>una mayúscula, una minúscula,<br>un número y un carácter especial.'
            });
        </script>
    <?php endif; ?>

    <script>
        const togglePassword = document.getElementById("togglePassword");
        const passwordField = document.getElementById("password");

        togglePassword.addEventListener("click", function () {
            const type = passwordField.type === "password" ? "text" : "password";
            passwordField.type = type;
        });
    </script>
</body>
</html>
