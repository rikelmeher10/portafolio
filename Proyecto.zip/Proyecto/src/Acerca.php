<?php
?>
<!DOCTYPE html>
<html> 
<head>
	<title>Ferreteria Tuerka & Tornillo</title>
	<link rel="icon" href="imagenes/icono.jpg">
	<link href="css/Estilos.css" rel="stylesheet" type="text/css">
	<link href="css/productos.css" rel="stylesheet" type="text/css">
	<link href="css/producto.css" rel="stylesheet" type="text/css">
	<link href="css/buscar.css" rel="stylesheet" type="text/css">
	<link href="css/botones.css" rel="stylesheet" type="text/css">
	<link href="css/Departamentos.css" rel="stylesheet" type="text/css">
	<link href="css/registrar.css" rel="stylesheet" type="text/css">
	<link href="css/ventana.css" rel="stylesheet" type="text/css">
	<link href="css/estilo.css" rel="stylesheet" type="text/css">
	<link href="css/pie.css" rel="stylesheet" type="text/css">
	<link
          rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css"
          integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g=="
          crossorigin="anonymous"
          referrerpolicy="no-referrer"
        />
</head>
<body>
<table>
<tr>
<td>
<center>
<img src="Imagenes/Tuerka.png" width="180px">
</center>
</td>
<td>
 <nav>
 <ul class="menu-horizontal">
 <li>
 <a href="#"><i class="fa-solid fa-bars"></i>  Departamento</a>
 <ul class="menu-vertical">
 <li><a href="#">Hogar</a></li>
 <li><a href="#">Herramientas</a></li>
 <li><a href="#">Iluminacion, eléctrico y ventilación</a></li>
 <li><a href="#">Fontaneria</a></li>
 <li><a href="#">Ferreteria y cerrajería</a></li>
 <li><a href="#">Materiales de construcción</a></li>
 <li><a href="#">Outoors y jardinería</a></li>
 <li><a href="#">Baños</a></li>
 <li><a href="#">Automotriz</a></li>
 <li><a href="#">Pintura</a></li>
 </ul>
 </li>
 </ul>
 </nav>
</td>
<td>
<div class="buscar">
<input type="text" class="buscar_texto" placeholder="Buscar...">
<a href="#" class="botonn"><i class="fa-solid fa-magnifying-glass"></i></a>
</div>
</td>
<td>
 <nav>
 <ul class="menu-horizontal">
 <li>
 <a href="index.php"><i class="fa-solid fa-user"></i> Mi cuenta</a>
 <ul class="menu-vertical">
 <li><a href="index.php"><i class="fa-solid fa-circle-user"></i>Administracion</a></li>
 <li><a href="salir.php"><i class="fa-solid fa-circle-user"></i>Cerrar Sesion</a></li>
 </ul>
 </li>
 </ul>
 </nav>
</td>
<td>
<input type="checkbox" id="btn-modal">

 <label for="btn-modal" class="lbl-modal">
 <i class="fa-solid fa-location-dot"></i> Retirar en</label>
 <div class="modal">
 <div class="contenedor">
 <header><i class="fa-solid fa-shop"></i><br>Elige tu sucursal</header>
 <label for="btn-modal">x</label>
 <br>
 <center>
 <p>Visualiza los productos disponibles en la sucursal de tu preferencia.</p>
 <br>
 <hr width="600">
 </center>
 <div class="contenido">
 <center>
 <br>
 <select>
 <option>--SUSCURSALES DISPONIBLES--</option>
 <option>S.S.CENTRO</option>
 <option>SOYAPANGO</option>
 <option>MEJICANOS</option>
 <option>SONSONATE</option>
 <option>ESCALON</option>
 <option>SAN MIGUELITO</option>
 </select>
 </center>
 </div>
 <br>
 <center>
 <hr width="600">
 </center>
 </div>
 </div>
</td>
<td>
	<div class="container">
        <div class="Menu">
            <label for="Menu"><i class="fa-solid fa-cart-shopping"></i> Carrito</label>
        </div>
    </div>
	
   <input type="checkbox" id="Menu">
		<div class="carro">
		   <div class="Menu-pagar">

				   <h2>Mi carretilla</h2>
				   <hr width="215" size="5%" color="#FF0000">
			</div>
			<a class="Vaciar" href="#">Vaciar Carrito</a>
			<a class="ver-carretilla" href="#">Pagar</a>
			<label for="Menu"><i class="fa-solid fa-xmark"></i></label>
		</div>
</td>
</table>
<br>
<hr>
<br>
	    <div class="menu">
		<center>
		        <tr>
                    <ul>
                        <a href="inicio.php"><i class="fa-solid fa-house"></i>Inicio</a>
						<a href="Acerca.php"><i class="fa-solid fa-book-open"></i>Acerca de Tuerka & Tornillo</a>
						<a href="Somos.php"><i class="fa-solid fa-users-between-lines"></i> Quienes somos</a>
						<a href="Servicios.php"><i class="fa-solid fa-table-list"></i>Servicios</a>
						<a href="Contactanos.php"><i class="fa-solid fa-address-book"></i> Contáctenos</a>
                    </ul>
				</tr>
			</center>
			</div>
			<br>
			<hr>
			<br>
</br>
<center>
 <h2 class="title1 text-warning mb-5"><strong>Acerca de Tuerka & Tornillo</strong></h2>
</center>
<hr>

<br>
  <p align="center">  Somos una compañía de El Salvador que inició en 2005. Nos dedicamos al comercio detallista y mayorista de productos de ferretería, herramientas,<br>
  pinturas, decoración, hogar, jardinería, materiales de construcción, eléctrico, iluminación y fontanería, de calidad y al mejor precio .</p>
  <br>
  <p align="center">Orgullosos de ser una empresa salvadoreña nos honramos de contar con numeroso personal que labora y aporta experiencia, criterio y esfuerzo<br>
  a nuestra compañía, a nuestros proveedores y principalmente a nuestros clientes. Todo ello sobre una base laboral de importantes prestaciones y<br>
  beneficios que contribuyen a la estabilidad de la empresa y sus puestos de trabajo.</p>
  <br>
  <p align="center">Relacionarse con Tuerka & Tornillo es de tener la posibilidad de elegir entre un amplio portafolio y prestigiosas marcas nacionales e internacionales.<br>
  Es experimentar la importancia de formar parte de nuestro personal, proveedores o clientes y de contar con una amplia gama de servicios, ideas y<br>
  soluciones para atender necesidades y proyectos de construcion, mantenimiento, reparación, comercio, industrias y decoración.</p>
  <br>
  <center>
         <h4>Vision</h4>
		 <br>
<p>Proveer soluciones con materiales y herramientas de ferretería para la construcción civil y pequeña industria,<br>
 manejando un surtido completo y permanente que permita llegar a los clientes salvadoreños con un servicio oportuno de<br>
 alta calidad a un precio competitivo.</p>
 <br>
<h4>Mision</h4>
<br>
<p>Ofrecer productos a los salvadoreños de la mejor calidad y menor precio del área de ferretería y materiales de construcción, esforzándonos en estar<br>
 al día en tecnología y crecer de la mano con nuestros colaboradores, para satisfacer las necesidades de nuestros clientes y así poder <br>ser mejores cada día como empresa y como personas.</p>
</center>
<br>
<center>
<h5 class="title text-warnig mb-5"><strong>Historia</strong>
</center>
<br>
<center>
<p align="center">Ferreteia Tuerka & Tornillo se creoen el 21 de junio de 2005. Con la vision de ofrecer productos de ferreteria de calidad. Con el tiempo y <br>
el esfuerzo impuesto, continua creciendo gradualmente dando soluciones efectivas a sus clientes que cada vez seran más y nos vemos con<br>
la necesidad de extendernos ampliando nuestro stock de productos, y adaptandonos ala tendencia del mercaddo ferretero.</p>
<br>
<p align="center">Ferrteria Tuerka & Tornillo cuenta mas de 15 colaboraciones quienes dan una atencion de calidad a nustros clientes quienes han sido la razón principal<br>
de nuestro crecimiento y con quienes mantenemos una excelente relacón comercial. En la actualidad hemos logrado crear una cartera muy extensa  <br>
desde clientes que nos visitan desde la comodidad de sus hogares hasta clientes como:constructoras, empresas privadas y estatales, <br>
hospitales, colegios, entre otros.</p>
</br>
<footer>
  <!-- Footer main -->
  <section class="ft-main">
    <div class="ft-main-item">
      <h2 class="ft-title">Información para el cliente</h2>
      <ul>
        <li><a href="#">Terminos y condiciones</a></li>
        <li><a href="#">Promociones</a></li>
        <li><a href="#">Política de Cookies</a></li>
        <li><a href="#">Forma de pago</a></li>
        <li><a href="#">Centro de ayuda</a></li>
      </ul>
    </div>
    <div class="ft-main-item">
      <h2 class="ft-title">Gestión de cuenta</h2>
      <ul>
        <li><a href="#">Mi cuenta</a></li>
        <li><a href="#">Registrarme</a></li>
        <li><a href="#">Pago seguro</a></li>
        <li><a href="#">Recuperar clave</a></li>
		<li><a href="#">Cómo comprar en línea</a></li>
      </ul>
    </div>
    <div class="ft-main-item">
      <h2 class="ft-title">Sitio de interés</h2>
      <ul>
        <li><a href="#">Sucursales</a></li>
        <li><a href="#">Empleos</a></li>
        <li><a href="#">Selector de color</a></li>
		<li><a href="#">Blog</a></li>
		<li><a href="#">Epapers</a></li>
      </ul>
    </div>
    <div class="ft-main-item">
      <h2 class="ft-title">Suscríbite</h2>
      <p>Enterate de nuestras promociones.</p>
      <form>
	  
        <input type="email" name="email" placeholder="Correo Electronico">
        <input type="submit" value="Subscribirme!">
      </form>
    </div>
  </section>
  <center>
<h2 class="ft-title">Siguenos en nuestras redes sociales</h2>
</center>
  <!-- Footer social -->
  <section class="ft-social">
    <ul class="ft-social-list">
      <li><a href="https://www.facebook.com/profile.php?id=100086444436009"><i class="fab fa-facebook"></i></a></li>
      <li><a href="https://twitter.com/tuerka_tornillo"><i class="fab fa-twitter"></i></a></li>
      <li><a href="https://www.instagram.com/tuerkatornillo/"><i class="fab fa-instagram"></i></a></li>
      <li><a href="https://www.youtube.com/channel/UC95J8kLu7HgUbNpr7FSFeUw"><i class="fab fa-youtube"></i></a></li>
    </ul>
  </section>

  <!-- Footer legal -->
  <section class="ft-legal">
    <ul class="ft-legal-list">
      <li><a href="#">Terms &amp; Conditions</a></li>
      <li><a href="#">Privacy Policy</a></li>
      <li>&copy; 2019 Copyright Nowrap Inc.</li>
    </ul>
  </section>
</footer>
	</body>
</html>
