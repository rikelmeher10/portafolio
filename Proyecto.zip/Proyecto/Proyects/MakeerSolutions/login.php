<?php 
require "conexion.php";
session_start();

$alert = "";
$loginSuccess = false;

if ($_POST) {
    $usuario = $_POST['usuario'];
    $password = $_POST['password'];

    $sql = "SELECT id, nombre, apellido, password FROM usuarios WHERE usuario='$usuario'";
    $resultado = $mysqli->query($sql);
    $num = $resultado->num_rows;

    if ($num > 0) {
        $row = $resultado->fetch_assoc();
        $password_bd = $row['password'];
        $pass_c = sha1($password);

        if ($password_bd == $pass_c) {
            $_SESSION['id'] = $row['id'];
            $_SESSION['nombre'] = $row['nombre'];
            $_SESSION['apellido'] = $row['apellido'];

            $loginSuccess = true; // Bandera para mostrar SweetAlert
        } else {
            $alert = "Usuario o Contraseña Incorrecta";
        }
    } else {
        $alert = "No existe el usuario";
    }
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>

    <!-- FontAwesome para iconos -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">

    <!-- Tu CSS -->
    <link rel="stylesheet" href="styles.css">

    <!-- SweetAlert -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <style>
        .field1 {
            position: relative;
            display: flex;
            align-items: center;
            border: 1px solid #ccc;
            border-radius: 20px;
            padding: 10px;
            width: 300px;
        }

        .field1 i {
            font-size: 16px;
            color: gray;
            margin-left: 10px;
        }

        .field1 input {
            border: none;
            outline: none;
            padding-left: 15px;
            font-size: 16px;
            width: 100%;
        }

        .back-button {
            display: block;
            text-align: center;
            margin-top: 20px;
        }

        .back-button a {
            display: inline-block;
            padding: 10px 20px;
            background-color: #0a0a23;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }

        .back-button a:hover {
            background-color: #333;
        }

        .password-container {
            position: relative;
        }

        .eye-icon {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
        }
    </style>
</head>

<body>
    <div class="wrapper">
        <div class="title">Iniciar Sesión</div>
        <center><img class="img-thumbnail" src="makeer.png" width="360"></center>

        <form method="POST">
            <div class="field1">
                <i class="fas fa-user"></i>
                <input type="text" required name="usuario" placeholder="Usuario" value="<?php echo htmlspecialchars($usuario ?? '') ?>">
            </div>
            <br>
            <div class="field1 password-container">
                <i class="fas fa-lock"></i>
                <input type="password" required name="password" placeholder="Contraseña" id="password">
                <span class="eye-icon" id="togglePassword">👁️</span>
            </div>

            <div class="content">
                <div class="checkbox">
                    <input type="checkbox" id="remember-me">
                    <label for="remember-me">Recordar</label>
                </div>
                <div class="pass-link"><a href="recuperar.php">¿Olvidó su contraseña?</a></div>
            </div>

            <div class="field">
                <input type="submit" value="Ingresar">
            </div>

            <div class="signup-link">¿No tienes una cuenta? <a href="register.php">Regístrate Ahora</a></div>

            <!-- Botón Volver al inicio -->
            <div class="back-button">
                <a href="index.php"><i class="fas fa-arrow-left"></i> Volver al inicio</a>
            </div>
        </form>
    </div>

    <!-- Mostrar SweetAlert si hay error -->
    <?php if (!empty($alert)) : ?>
        <script>
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: '<?php echo $alert; ?>',
                confirmButtonColor: '#3085d6'
            });
        </script>
    <?php endif; ?>

    <!-- Mostrar SweetAlert si login fue exitoso -->
    <?php if ($loginSuccess) : ?>
        <script>
            Swal.fire({
                icon: 'success',
                title: '¡Inicio de Sesión Exitoso!',
                text: 'Bienvenido a Makeer',
                confirmButtonText: 'Aceptar',
                confirmButtonColor: '#3085d6'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = 'index.php';
                }
            });
        </script>
    <?php endif; ?>

    <script>
        // Mostrar/ocultar contraseña
        const togglePassword = document.getElementById("togglePassword");
        const passwordField = document.getElementById("password");

        togglePassword.addEventListener("click", function() {
            const type = passwordField.type === "password" ? "text" : "password";
            passwordField.type = type;
        });
    </script>
</body>

</html>
