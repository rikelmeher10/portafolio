<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="static/styles.css">
    <title>MAKEER SOLUTIONS</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
    .dropdown {
        position: relative;
        display: inline-block;
    }
    .user-button {
        background: none;
        border: none;
        color: white;
        cursor: pointer;
        font-size: 16px;
        display: flex;
        align-items: center;
        gap: 6px;
    }
    .dropdown-content {
        display: none;
        position: absolute;
        right: 0;
        background-color: white;
        min-width: 140px;
        box-shadow: 0px 8px 16px rgba(0,0,0,0.2);
        z-index: 1;
        border-radius: 6px;
        overflow: hidden;
    }
    .dropdown-content a {
        color: black;
        padding: 10px 14px;
        text-decoration: none;
        display: block;
    }
    .dropdown-content a:hover {
        background-color: #f1f1f1;
    }
    .dropdown:hover .dropdown-content {
        display: block;
    }
	
	
	
    </style>
</head>
<body>
<nav class="navbar">
    <div class="logo">MAKEER SOLUTIONS</div>
    <ul class="nav-links">
        <li><a href="index.php">INICIO</a></li>
        <li><a href="acerca.html">ACERCA DE NOSOTROS</a></li>
        <li><a href="servicios.html">SERVICIOS</a></li>
        <li><a href="contacto.html">CONTACTO</a></li>
    </ul>
    <div class="auth-icon">
        <?php if (isset($_SESSION['nombre']) && isset($_SESSION['apellido'])): ?>
        <div class="dropdown">
            <button class="user-button">
                <i class="fas fa-user-circle"></i>
                <?php echo $_SESSION['nombre'] . ' ' . $_SESSION['apellido']; ?>
            </button>
            <div class="dropdown-content">
                <a href="perfil.php">Perfil</a>
                <a href="cerrar.php">Cerrar sesión</a>
            </div>
        </div>
        <?php else: ?>
        <a href="login.php" title="Iniciar sesión o registrarse">
            <i class="fas fa-user-circle"></i>
        </a>
        <?php endif; ?>
    </div>
</nav>

<header class="hero-section">
    <h1>Bienvenido a Nuestra Página Web</h1>
</header>

<!-- Resto de tu contenido index aquí -->
    <main>
	<h2 class="section-header">Nuestra Identidad Corporativa</h2>
        <section id="acerca" class="about-section">
            <!--<h2 class="section-header">Acerca de Nosotros</h2>-->
            <div class="cards-container">
                <!-- Misión -->
                <div class="card">
                    <i class="fas fa-bullhorn"></i>
                    <h3>Misión</h3>
                    <p>Somos una empresa de consultoría que brinda metodologías y estrategias innovadoras a nuestros clientes a través de nuestros servicios, impulsando su crecimiento empresarial. Nos enfocamos en ofrecer asesoramiento personalizado, basado en el conocimiento experto y el uso de mejores prácticas, para ayudar a las empresas a alcanzar sus objetivos con éxito.</p>
                </div>

                <!-- Visión -->
                <div class="card">
                    <i class="fas fa-eye"></i>
                    <h3>Visión</h3>
                    <p>Ser la empresa de consultoría líder en el mercado, reconocida por nuestra excelencia, compromiso y capacidad para generar valor en los negocios de nuestros clientes. Aspiramos a convertirnos en un socio clave y estratégico, que impulse la transformación y el éxito de las organizaciones en un entorno competitivo y en constante evolución.</p>
                </div>

                <!-- Valores -->
                <div class="card">
                    <i class="fas fa-handshake"></i>
                    <h3>Valores</h3>
                    <p><strong>Compromiso:</strong> Nos dedicamos a brindar cambios de alta calidad con responsabilidad y profesionalismo.</p>
                    <p><strong>Innovación:</strong> Buscamos constantemente nuevas ideas y metodologías para ofrecer cambios efectivos y adaptados a las necesidades del cliente.</p>
                    <p><strong>Excelencia:</strong> Nos esforzamos por superar las expectativas a través de un servicio de consultoría de primer nivel.</p>
                    <p><strong>Confidencialidad:</strong> Resguardamos la información sensible de nuestros clientes con total profesionalismo, asegurando la protección de datos y el cumplimiento de normativas.</p>
                    <p><strong>Adaptabilidad:</strong> Nos ajustamos a las necesidades específicas de cada cliente, respondiendo con flexibilidad a los cambios que puedan surgir durante la consultoría.</p>
                </div>

                <!-- Objetivos -->
                <div class="card">
                    <i class="fas fa-trophy"></i>
                    <h3>Objetivos</h3>
                    <p><strong>Diagnósticos organizacionales:</strong> Realizar diagnósticos organizacionales precisos para garantizar mejoras en los procesos internos de las empresas.</p>
                    <p><strong>Cumplimiento normativo:</strong> Garantizar el cumplimiento normativo y financiero de los clientes, asegurando que sus operaciones cumplan con las regulaciones fiscales, laborales y contables vigentes.</p>
                    <p><strong>Optimización de decisiones:</strong> Optimizar la toma de decisiones empresariales mediante análisis de datos y evaluación de riesgos.</p>
                    <p><strong>Fortalecimiento de la competitividad:</strong> Fortalecer la competitividad de las empresas a través de la implementación de mejores prácticas en gestión.</p>
                </div>

                <!-- Historia -->
                <div class="card">
                    <i class="fas fa-history"></i>
                    <h3>Historia</h3>
                    <p><strong>Fundación de MAKEER SOLUTIONS:</strong> MAKEER SOLUTIONS fue fundada en el año 2025 por un equipo de profesionales apasionados y decididos a proporcionar servicios de alta calidad en las áreas de Supply Chain, Finanzas, Contabilidad, Gestión Documental, IT y producción.</p>
                    <p>Nuestra organización se compromete a brindar cambios personalizados y adaptados a las necesidades de cada cliente, siempre con un enfoque basado en la excelencia, innovación y compromiso con el éxito.</p>
                </div>
            </div>
        </section>
    </main>

 <footer>
	<div class="cards">	
        <div class="social-links">
		<h5>Nuestras Redes Sociales</h5>
            <a href="https://www.facebook.com/makeersolutions" target="_blank"><i class="fab fa-facebook"></i></a>
            <a href="https://instagram.com" target="_blank"><i class="fab fa-instagram"></i></a>
            <a href="https://wa.me/1234567890" target="_blank"><i class="fab fa-whatsapp"></i></a>
        </div>
	</div>
	<h5>&copy; 2025 todos los derechos reservados. MAKEER SOLUTIONS</h5>
    </footer>
</body>
</html>

