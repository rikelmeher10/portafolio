<html> 
	<head>
		<title>Generando la Base de Datos</title>
	</head>
	<body>
	<h1>Base de Datos</h1>
	
	<?php
		//Estableciendo conexioncon el motor de BD
		//$Conectado=mysql_connect("localhost","root","");
		$Conectado=mysqli_connect("localhost","root","");
		
		//Creando la consulta para crear una BD si es que no existe
		$Consulta="CREATE DATABASE IF NOT EXISTS BD_ferreteria;";
		//$EjecutarConsulta=mysql_query($Consulta, $Conectado);
		$EjecutarConsulta=mysqli_query($Conectado, $Consulta);
		
		//Seleccionamos la BD recien creada
		//mysql_select_db("BD_alumno", $Conectado);
		mysqli_select_db($Conectado, "BD_ferreteria");
		
		//TABLA DE CATEGORIAS
		
		//Si la tabla existe se elimina de la BD
		$Consulta="DROP TABLE IF EXISTS categoria;";
		//$EjecutarConsulta=mysql_query($Consulta, $Conectado);
		$EjecutarConsulta=mysqli_query($Conectado, $Consulta);
		
		//Creamos la estructura de la tabla
		$Consulta="CREATE TABLE categoria (id_categoria INT PRIMARY KEY NOT NULL AUTO_INCREMENT, 
		nombre varchar(100) COLLATE utf8_spanish_ci NOT NULL, 
		descripcion varchar(100) COLLATE utf8_spanish_ci NOT NULL);";
		//$EjecutarConsulta=mysql_query($Consulta, $Conectado);
		$EjecutarConsulta=mysqli_query($Conectado, $Consulta);
		
		$Consulta="INSERT INTO categoria (id_categoria, nombre, descripcion)
		VALUES
		(1,'Industria', 'Aquí encontraras todo tipo de herramientas'),
		(2,'Construcción - Madera', 'Aquí encontraras todo tipo de herramientas'),
		(3,'Sellantes - Fijación y Tornillería', 'Aquí encontraras todo tipo de herramientas'),
		(4,'Pinturas y Complementos', 'Aquí encontraras todo tipo de herramientas'),
		(5,'Protección y Vestuario', 'Aquí encontraras todo tipo de herramientas'),
		(6,'Equipos de trabajo', 'Aquí encontraras todo tipo de herramientas'),
		(7,'Electroportátiles y Accesorios', 'Aquí encontraras todo tipo de herramientas'),
		(8,'Material Eléctrico', 'Aquí encontraras todo tipo de herramientas'),
		(9,'Calefacción y Ventilación', 'Aquí encontraras todo tipo de herramientas'),
		(10,'Baño y Fontanería', 'Aquí encontraras todo tipo de herramientas'),
		(11,'Cerrajería', 'Aquí encontraras todo tipo de herramientas'),
		(12,'Ferretería Doméstica', 'Aquí encontraras todo tipo de herramientas');";
		
		//$EjecutarConsulta=mysql_query($Consulta, $Conectado);
		$EjecutarConsulta=mysqli_query($Conectado, $Consulta);
		
		//TABLA DE PROVEEDORES
		
		//Si la tabla existe se elimina de la BD
		$Consulta="DROP TABLE IF EXISTS proveedor;";
		//$EjecutarConsulta=mysql_query($Consulta, $Conectado);
		$EjecutarConsulta=mysqli_query($Conectado, $Consulta);
		
		//Creamos la estructura de la tabla
		$Consulta="CREATE TABLE proveedor (id_proveedor INT PRIMARY KEY NOT NULL AUTO_INCREMENT, 
		nombre varchar(100) COLLATE utf8_spanish_ci NOT NULL, 
		pais varchar(100) COLLATE utf8_spanish_ci NOT NULL, 
		ciudad varchar(100) COLLATE utf8_spanish_ci NOT NULL, 
		direccion varchar(100) COLLATE utf8_spanish_ci NOT NULL, 
		telefono varchar(100) COLLATE utf8_spanish_ci NOT NULL, 
		correo varchar(100) COLLATE utf8_spanish_ci NOT NULL);";
		//$EjecutarConsulta=mysql_query($Consulta, $Conectado);
		$EjecutarConsulta=mysqli_query($Conectado, $Consulta);
		
		$Consulta="INSERT INTO proveedor (id_proveedor, nombre, pais, ciudad, direccion, telefono, correo)
		VALUES
		(1,'Alibaba', 'España', 'Madrid', 'C/ Araquil, 67', '2222-2886', 'alibaba.com'),
		(2,'Maxi', 'Mexico', 'Mexico DC', 'DC/ Chiapas, 54', '2222-2345', 'maxi.com'),
		(3,'Compa', 'Costa Rica', 'San José', 'San José, 55', '2224-2345', 'compa.com'),
		(4,'Alexa', 'EEUU', 'New York', 'Las Vegas, 23', '222-234', 'alexa.com'),
		(5,'Rocal', 'Brazil', 'San Juan', 'San Juan, 51', '224-334', 'rocal.com'),
		(6,'Focal', 'Argentina', 'Buenos Aires', 'Buenos Aires, 45', '456-235', 'focal.com'),
		(7,'Ancla', 'Perú', '´Perú', 'San Bartolo, 45', '246-245', 'ancla.com'),
		(8,'Zoza', 'Colombia', 'Colombia', 'Colonia Colon, 74', '2822-2045', 'zoza.com'),
		(9,'Doban', 'Honduras', 'Honduras', 'Hon, 55', '8224-9345', 'doban.com'),
		(10,'Punpa', 'Guatemala', 'Guatemala DC', 'DC/ Guate, 64', '2722-5345', 'punpa.com'),
		(11,'Alen', 'El Salvador', 'San Salvador', 'Salvador del Mundo', '2228-2315', 'alen.com'),
		(12,'Foda', 'Mexico', 'Mexico DC', 'DC/ Chiapas, 54', '5222-6345', 'foda.com'),
		(13,'Polpa', 'Costa Rica', 'San José', 'San José, 55', '7224-2345', 'polpa.com'),
		(15,'Camba', 'EEUU', 'New York', 'Las Vegas, 23', '222-734', 'camba.com');";
		//$EjecutarConsulta=mysql_query($Consulta, $Conectado);
		$EjecutarConsulta=mysqli_query($Conectado, $Consulta);
		
		
		//TABLA DE CLIENTES
		//Si la tabla existe se elimina de la BD
		$Consulta="DROP TABLE IF EXISTS cliente;";
		//$EjecutarConsulta=mysql_query($Consulta, $Conectado);
		$EjecutarConsulta=mysqli_query($Conectado, $Consulta);
		
		//Creamos la estructura de la tabla
		$Consulta="CREATE TABLE cliente (idcliente INT PRIMARY KEY NOT NULL AUTO_INCREMENT, 
		nombre varchar(100) COLLATE utf8_spanish_ci NOT NULL, 
		apellidos varchar(100) COLLATE utf8_spanish_ci NOT NULL,
		direccion varchar(200) COLLATE utf8_spanish_ci NOT NULL,
		telefono varchar(12) COLLATE utf8_spanish_ci NOT NULL,
		correo varchar(200) COLLATE utf8_spanish_ci NOT NULL,
		usuario_id INT NOT NULL, estado INT NOT NULL DEFAULT 1);";
		//$EjecutarConsulta=mysql_query($Consulta, $Conectado);
		$EjecutarConsulta=mysqli_query($Conectado, $Consulta);
		
		$Consulta="INSERT INTO cliente (idcliente, nombre, apellidos, direccion, telefono, correo, usuario_id, estado)
		VALUES
		(1,'Carlos José', 'Hernándes Martínes','San Salvador', '76789867', 'carlosHer@gmail.com',1,1),
		(2,'Cristian Alfredo', 'Alas Castellanos', 'La Paz', '78782867', 'alfreruiz@gmail.com',1,1),
		(3,'Carlos Manuel', 'Velasquez Morales', 'San Salvador', '75459567', 'carlosmoral@gmail.com',1,1),
		(4,'Daniel Eduardo', 'Ruiz Alas', 'La Paz', '6345-5654', 'daniruiz@gmail.com',1,1),
		(5,'Aracely Beatriz', 'Perez Flores', 'Santa Ana', '73468956', 'beaperez@gmail.com',1,1),
		(6,'Edwin Elías', 'Perez Mendez', 'Usulutan', '66849864', 'elimendez@gmail.com',1,1),
		(7,'Rebeca Abigail', 'Melendez Aguilar','Lourdes Colon', '63457634', 'rebeagui@gmail.com',1,1),
		(8,'Rocio Esmeralda', 'Ortiz Martinez', 'San Salvador', '76839867', 'rocioortiz@gmail.com',1,1),
		(9,'Patricia Alejandra', 'Palma Castro', 'Santo Tomas', '63452894', 'patricpalma@gmail.com',1,1),
		(10,'José Luis', 'Moreno Lopez', 'San Salvador', '69452743', 'josemoreno@gmail.com',1,1),
		(11,'Luis Enrique', 'Mendoza Lobato','Metapan', '73322512', 'luislobato@gmail.com',1,1),
		(12,'José Jaime', 'Martínez Serrano', 'La Paz', '75439867', 'josemartin@gmail.com',1,1),
		(13,'José Rodrigo', 'Mejia Velasquez','San Salvador', '67459867', 'rodrigovela@gmail.com',1,1);";
		//$EjecutarConsulta=mysql_query($Consulta, $Conectado);
		$EjecutarConsulta=mysqli_query($Conectado, $Consulta);
		
		//TABLA DE CONFIGURACION
		//Si la tabla existe se elimina de la BD
		$Consulta="DROP TABLE IF EXISTS configuracion;";
		//$EjecutarConsulta=mysql_query($Consulta, $Conectado);
		$EjecutarConsulta=mysqli_query($Conectado, $Consulta);
		
		//Creamos la estructura de la tabla
		$Consulta="CREATE TABLE configuracion (id INT PRIMARY KEY NOT NULL AUTO_INCREMENT, 
		nombre varchar(100) COLLATE utf8_spanish_ci NOT NULL, 
		telefono varchar(12) COLLATE utf8_spanish_ci NOT NULL,
        email varchar(100) COLLATE utf8_spanish_ci NOT NULL,		
		direccion text COLLATE utf8_spanish_ci NOT NULL);";
		//$EjecutarConsulta=mysql_query($Consulta, $Conectado);
		$EjecutarConsulta=mysqli_query($Conectado, $Consulta);
		
		$Consulta="INSERT INTO configuracion (id, nombre, telefono, email, direccion)
		VALUES(1, 'Tuerka y Tornillo', '925491523', 'rikelmartin2580@gamil.com', 'Lima');";
		//$EjecutarConsulta=mysql_query($Consulta, $Conectado);
		$EjecutarConsulta=mysqli_query($Conectado, $Consulta);
		
		//TABLA DE PERMISOS
		//Si la tabla existe se elimina de la BD
		$Consulta="DROP TABLE IF EXISTS permisos;";
		//$EjecutarConsulta=mysql_query($Consulta, $Conectado);
		$EjecutarConsulta=mysqli_query($Conectado, $Consulta);
		
		//Creamos la estructura de la tabla
		$Consulta="CREATE TABLE permisos (id INT PRIMARY KEY NOT NULL AUTO_INCREMENT, 
		nombre varchar(30) NOT NULL);";
		//$EjecutarConsulta=mysql_query($Consulta, $Conectado);
		$EjecutarConsulta=mysqli_query($Conectado, $Consulta);
		
		$Consulta="INSERT INTO permisos (id, nombre)
		VALUES(1, 'configuración'),
			(2, 'usuarios'),
			(3, 'clientes'),
			(4, 'productos'),
			(5, 'categorias'),
			(6, 'proveedores'),
			(7, 'ventas'),
			(8, 'nueva_venta');";
		//$EjecutarConsulta=mysql_query($Consulta, $Conectado);
		$EjecutarConsulta=mysqli_query($Conectado, $Consulta);
		
		//TABLA DE USUARIO
		
		//Si la tabla existe se elimina de la BD
		$Consulta="DROP TABLE IF EXISTS usuario;";
		//$EjecutarConsulta=mysql_query($Consulta, $Conectado);
		$EjecutarConsulta=mysqli_query($Conectado, $Consulta);
		
		//Creamos la estructura de la tabla
		$Consulta="CREATE TABLE usuario (idusuario INT PRIMARY KEY NOT NULL AUTO_INCREMENT, 
		nombre varchar(100) COLLATE utf8_spanish_ci NOT NULL, 
		apellidos varchar(100) COLLATE utf8_spanish_ci NOT NULL,
		correo varchar(100) COLLATE utf8_spanish_ci NOT NULL, 
		usuario varchar(20) COLLATE utf8_spanish_ci NOT NULL, 
		clave varchar(50) COLLATE utf8_spanish_ci NOT NULL);";
		//$EjecutarConsulta=mysql_query($Consulta, $Conectado);
		$EjecutarConsulta=mysqli_query($Conectado, $Consulta);
		
		$Consulta="INSERT INTO usuario (idusuario, nombre, apellidos,correo, usuario, clave)
		VALUES
		(1, 'José Elías','Hernández Pérez', 'joseperez@gmail.com', 'admin', '21232f297a57a5a743894a0e4a801fc3'),
        (2, 'José Ángel','Hernández López', 'angel@gmail.com', 'admin', 'f4f068e71e0d87bf0ad51e6214ab84e9'),
		(3, 'Luis Antonio', 'Peréz Hernández', 'luisantonio@gmail.com', 'admin', '4a181673429f0b6abbfd452f0f3b5950'),
		(4, 'Patricia Noemi', 'Hernandez Castro', 'patricia@gmail.com', 'admin', '823fec7a2632ea7b498c1d0d11c11377'),
		(5, 'Wendy Marielos', 'Martinez Palacios', 'wendymar@gmail.com', 'admin', '2cff03e4b9eb85b3bf5e924ccdc1348d'),
		(6, 'Nelson Rodrigo', 'Gonzalez Escobar', 'rodrigues@gmail.com', 'vendedor', 'a4e360681676c770121e891f8c407572'),
		(7, 'Daniela Margarita', 'Hernandez Ramos', 'daniela@gmail.com', 'vendedor', '07a88e756847244f3496f63f473d6085'),
		(8, 'Anderson Jose', 'Hernandez Alvarado', 'anderson25@gmail.com', 'vendedor', '89ba023086e37a345839e0c6a0d272eb'),
		(9, 'Levi Ernesto','Hernández Pérez', 'leviern@gmail.com', 'vendedor', '8f91bdb4de0142710ac1718345b96308'),
		(10, 'Karen Estela','Martínez Magaña', 'estela@gmail.com', 'vendedor', 'ba952731f97fb058035aa399b1cb3d5c');";
		//$EjecutarConsulta=mysql_query($Consulta, $Conectado);
		$EjecutarConsulta=mysqli_query($Conectado, $Consulta);
		
		//TABLA DETALLE DE PERMISOS
		//Si la tabla existe se elimina de la BD
		$Consulta="DROP TABLE IF EXISTS detalle_permisos;";
		//$EjecutarConsulta=mysql_query($Consulta, $Conectado);
		$EjecutarConsulta=mysqli_query($Conectado, $Consulta);
		
		//Creamos la estructura de la tabla
		$Consulta="CREATE TABLE detalle_permisos (id INT PRIMARY KEY NOT NULL AUTO_INCREMENT, 
		id_permiso INT NOT NULL,
		id_usuario INT NOT NULL);";
		//$EjecutarConsulta=mysql_query($Consulta, $Conectado);
		$EjecutarConsulta=mysqli_query($Conectado, $Consulta);
		
		$Consulta="INSERT INTO detalle_permisos (id, id_permiso, id_usuario)
		VALUES(1, 3, 6),
			(2, 4, 6),
			(3, 5, 6),
			(4, 6, 6),
			(5, 7, 6),
			(6, 8, 6);";
		//$EjecutarConsulta=mysql_query($Consulta, $Conectado);
		$EjecutarConsulta=mysqli_query($Conectado, $Consulta);
		
		//TABLA DE PRODUCTOS
		//Si la tabla existe se elimina de la BD
		$Consulta="DROP TABLE IF EXISTS producto;";
		//$EjecutarConsulta=mysql_query($Consulta, $Conectado);
		$EjecutarConsulta=mysqli_query($Conectado, $Consulta);
		
		//Creamos la estructura de la tabla
		$Consulta="CREATE TABLE producto (codproducto INT PRIMARY KEY NOT NULL AUTO_INCREMENT, 
		codigo varchar(100) COLLATE utf8_spanish_ci NOT NULL, 
		descripcion varchar(200) COLLATE utf8_spanish_ci NOT NULL, 
		precio decimal(10,2)NOT NULL,
		existencia INT NOT NULL,
		usuario_id INT NOT NULL, estado INT NOT NULL DEFAULT 1);";
		//$EjecutarConsulta=mysql_query($Consulta, $Conectado);
		$EjecutarConsulta=mysqli_query($Conectado, $Consulta);
		
		$Consulta="INSERT INTO producto (codproducto, codigo, descripcion, precio, existencia, usuario_id, estado)
		VALUES
		(1, '121', 'Taladro', '5.50', 180, 1, 1),
		(2, '122', 'Juego de Llaves', '5.00', 8, 1, 1),
		(3, '123', 'Escalera', '13.00', 55, 1, 1),
		(4, '124', 'Alícate', '150.00', 50, 0, 1),
		(5, '125', 'Cinta de Medir', '5.50', 180, 1, 1),
		(6, '126', 'Destornillador de Paleta', '5.00', 8, 1, 1),
		(7, '127', 'Martillo', '13.00', 55, 1, 1),
		(8, '128', 'Pala', '150.00', 50, 0, 1),
		(9, '129', 'Serrucho', '5.50', 180, 1, 1),
		(10, '130', 'Cortadoras de Metal', '5.00', 8, 1, 1),
		(11, '131', 'Ladrillos','45',55, 1, 1),
		(12, '132', 'Ceramica', '150.00', 50, 1, 1),
		(13, '133', 'Clavos', '5.50', 180, 1, 1),
		(14, '134', 'Brochas', '5.00', 8, 1, 1),
		(15, '135', 'Cerraduras', '13.00', 55, 1, 1),
		(16, '136', 'Candados', '150.00', 50, 0, 1),
		(17, '137', 'Pinzas', '5.00', 8, 1, 1),
		(18, '138', 'Tenaza de corte', '13.00', 55, 1, 1),
		(19, '139', 'Cascos', '150.00', 50, 0, 1),
		(20, '140', 'Rampas', '30.00', 50, 0, 1);";
		//$EjecutarConsulta=mysql_query($Consulta, $Conectado);
		$EjecutarConsulta=mysqli_query($Conectado, $Consulta);
		
		//TABLA DETALLE TEMP
		//Si la tabla existe se elimina de la BD
		$Consulta="DROP TABLE IF EXISTS detalle_temp;";
		//$EjecutarConsulta=mysql_query($Consulta, $Conectado);
		$EjecutarConsulta=mysqli_query($Conectado, $Consulta);
		
		//Creamos la estructura de la tabla
		$Consulta="CREATE TABLE detalle_temp (id INT PRIMARY KEY NOT NULL AUTO_INCREMENT, 
		id_usuario varchar(50) COLLATE utf8_spanish_ci NOT NULL,
		id_producto INT NOT NULL, 
		cantidad INT NOT NULL,
		precio_venta  decimal(10,2) NOT NULL,
		total decimal(10,2) NOT NULL);";
		//$EjecutarConsulta=mysql_query($Consulta, $Conectado);
		$EjecutarConsulta=mysqli_query($Conectado, $Consulta);
		
		/*
		$Consulta="INSERT INTO producto (id, id_usuario, id_producto, cantidad, precio_venta, total)
		VALUES(2, '321', 'Tornillos Medianos lb', '5.50', 180, 1, 1),
		(3, '654', 'Tuercas para tornillos lb', '5.00', 8, 1, 1),
		(4, '987', 'Martillo', '13.00', 55, 1, 1),
		(5, '12345', 'Taladro', '150.00', 50, 0, 1),
		(6, '12345', 'Juego de Herramientas', '30.00', 50, 0, 0);";
		//$EjecutarConsulta=mysql_query($Consulta, $Conectado);
		$EjecutarConsulta=mysqli_query($Conectado, $Consulta);
		*/
		
		//TABLA VENTAS
		
		//Si la tabla existe se elimina de la BD
		$Consulta="DROP TABLE IF EXISTS ventas;";
		//$EjecutarConsulta=mysql_query($Consulta, $Conectado);
		$EjecutarConsulta=mysqli_query($Conectado, $Consulta);
		
		//Creamos la estructura de la tabla
		$Consulta="CREATE TABLE ventas (id INT PRIMARY KEY NOT NULL AUTO_INCREMENT, 
		id_cliente INT NOT NULL,
		total decimal(10,2) NOT NULL,
		id_usuario INT NOT NULL, 
		fecha timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp());";
		//$EjecutarConsulta=mysql_query($Consulta, $Conectado);
		$EjecutarConsulta=mysqli_query($Conectado, $Consulta);
		
		$Consulta="INSERT INTO ventas (id, id_cliente, total, id_usuario, fecha)
		VALUES(1, 1, '42.00', 1, '2021-05-16 14:35:54'),
				(2, 1, '39.00', 1, '2021-05-16 14:39:39');";
		//$EjecutarConsulta=mysql_query($Consulta, $Conectado);
		$EjecutarConsulta=mysqli_query($Conectado, $Consulta);
		
		//TABLA DETALLE VENTA
		//Si la tabla existe se elimina de la BD
		$Consulta="DROP TABLE IF EXISTS detalle_venta;";
		//$EjecutarConsulta=mysql_query($Consulta, $Conectado);
		$EjecutarConsulta=mysqli_query($Conectado, $Consulta);
		
		//Creamos la estructura de la tabla
		$Consulta="CREATE TABLE detalle_venta (id INT PRIMARY KEY NOT NULL AUTO_INCREMENT, 
		id_producto INT NOT NULL,
		id_venta INT NOT NULL, 
		cantidad INT NOT NULL,
		precio decimal(10,2) NOT NULL);";
		//$EjecutarConsulta=mysql_query($Consulta, $Conectado);
		$EjecutarConsulta=mysqli_query($Conectado, $Consulta);
		
		$Consulta="INSERT INTO detalle_venta (id, id_producto, id_venta, cantidad, precio)
		VALUES(1, 4, 1, 2, '13.00'),
			(2, 3, 1, 1, '16.00'),
			(3, 4, 2, 3, '13.00');";
		//$EjecutarConsulta=mysql_query($Consulta, $Conectado);
		$EjecutarConsulta=mysqli_query($Conectado, $Consulta);
		
		
		//Verificando si la BD se creo.
		if($EjecutarConsulta)
		{
			echo ("La BD y la tabla fueron creados de forma satisfactoria.<br>");
			
		}
		else
		{
			echo("Surgio problema para crear la BD.<br>");
			echo("El problema es: <br>");
			//echo("Codigo de error: <b>".mysql_errno()."</b><br>");
			echo("Codigo de error: <b>".mysqli_errno($Conectado)."</b><br>");
		}
		
		//mysql_close($Conectado);
		mysqli_close($Conectado);
	?>
	</body>
</html>