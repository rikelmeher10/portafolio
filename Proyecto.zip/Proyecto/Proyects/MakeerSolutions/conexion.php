<?php
	
	$mysqli = new mysqli("localhost", "root", "", "bdmakeer");
	
?>
