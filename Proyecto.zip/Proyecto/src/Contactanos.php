<?php
?>
<!DOCTYPE html>
<html> 
<head>
    <title>Ferreteria Tuerka & Tornilli</title>
    <link rel="icon" href="imagenes/icono.jpg">
	<link href="css/Estilos.css" rel="stylesheet" type="text/css">
	<link href="css/pie.css" rel="stylesheet" type="text/css">
	<link href="css/productos.css" rel="stylesheet" type="text/css">
	<link href="css/carrusel.css" rel="stylesheet" type="text/css">
	<link href="css/contacto.css" rel="stylesheet" type="text/css">
	<link href="css/buscar.css" rel="stylesheet" type="text/css">
	<link href="css/botones.css" rel="stylesheet" type="text/css">
	<link href="css/Departamentos.css" rel="stylesheet" type="text/css">
	<link href="css/registrar.css" rel="stylesheet" type="text/css">
	<link href="css/ventana.css" rel="stylesheet" type="text/css">
	<link href="css/estilo.css" rel="stylesheet" type="text/css">
	<link href="css/pie.css" rel="stylesheet" type="text/css">
	<link
          rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css"
          integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g=="
          crossorigin="anonymous"
          referrerpolicy="no-referrer"
        />
		
</head>
<body>
<table>
<tr>
<td>
<center>
<img src="Imagenes/Tuerka.png" width="200px">
</center>
</td>
<td>
 <nav>
 <ul class="menu-horizontal">
 <li>
 <a href="#"><i class="fa-solid fa-bars"></i>Departamento</a>
 <ul class="menu-vertical">
 <li><a href="#">Hogar</a></li>
 <li><a href="#">Herramientas</a></li>
 <li><a href="#">Iluminacion, eléctrico y ventilación</a></li>
 <li><a href="#">Fontaneria</a></li>
 <li><a href="#">Ferreteria y cerrajería</a></li>
 <li><a href="#">Materiales de construcción</a></li>
 <li><a href="#">Outoors y jardinería</a></li>
 <li><a href="#">Baños</a></li>
 <li><a href="#">Automotriz</a></li>
 <li><a href="#">Pintura</a></li>
 </ul>
 </li>
 </ul>
 </nav>
</td>
<td>
<div class="buscar">
<input type="text" class="buscar_texto" placeholder="Buscar...">
<a href="#" class="botonn"><i class="fa-solid fa-magnifying-glass"></i></a>
</div>
</td>
<td>
 <nav>
 <ul class="menu-horizontal">
 <li>
 <a href="index.php"><i class="fa-solid fa-user"></i> Mi cuenta</a>
 <ul class="menu-vertical">
 <li><a href="index.php"><i class="fa-solid fa-circle-user"></i>Administracion</a></li>
 <li><a href="salir.php"><i class="fa-solid fa-circle-user"></i>Cerrar Sesion</a></li>
 </ul>
 </li>
 </ul>
 </nav>
</td>
<td>
<input type="checkbox" id="btn-modal">
 <label for="btn-modal" class="lbl-modal">
 <i class="fa-solid fa-location-dot"></i>Retirar en</label>
 <div class="modal">
 <div class="contenedor">
 <header><i class="fa-solid fa-shop"></i><br>Elige tu sucursal</header>
 <label for="btn-modal">x</label>
 <br>
 <center>
 <p>Visualiza los productos disponibles en la sucursal de tu preferencia.</p>
 <br>
 <hr width="600">
 </center>
 <div class="contenido">
 <center>
 <br>
 <select>
 <option>--SUSCURSALES DISPONIBLES--</option>
 <option>S.S.CENTRO</option>
 <option>SOYAPANGO</option>
 <option>MEJICANOS</option>
 <option>SONSONATE</option>
 <option>ESCALON</option>
 <option>SAN MIGUELITO</option>
 </select>
 </center>
 <br>
 <center>
 <hr width="600">
 </center>
 </div>
 </div>
 </div>
</td>
<td>
	<div class="container">
        <div class="Menu">
            <label for="Menu"><i class="fa-solid fa-cart-shopping"></i> Carrito</label>
        </div>
    </div>
	
   <input type="checkbox" id="Menu">
		<div class="carro">
		   <div class="Menu-pagar">

				   <h2>Mi carretilla</h2>
				   <hr width="215" size="5%" color="#FF0000">
			</div>
			<a class="Vaciar" href="#">Vaciar Carrito</a>
			<a class="ver-carretilla" href="#">Pagar</a>
			<label for="Menu"><i class="fa-solid fa-xmark"></i></label>
		</div>
</td>
</table>
<br>
<hr>
<br>
	    <div class="menu">
		<center>
		        <tr>
                    <ul>
                        <a href="inicio.php"><i class="fa-solid fa-house"></i>Inicio</a>
						<a href="Acerca.php"><i class="fa-solid fa-book-open"></i>Acerca de Tuerka & Tornillo</a>
						<a href="Somos.php"><i class="fa-solid fa-users-between-lines"></i> Quienes somos</a>
						<a href="Servicios.php"><i class="fa-solid fa-table-list"></i>Servicios</a>
						<a href="Contactanos.php"><i class="fa-solid fa-address-book"></i> Contactanos</a>
                    </ul>
				</tr>
			</center>
			</div>
			<br>
			<hr>
			<br>
			<center>
			<h1>
				Contáctenos
				<br>
			</h1>
			<hr width="1100">
			<br>
			<p>Sus consultas y opiniones son muy importantes. Puede hacerlo en las siguientes opciones:</p>
			<br>
			<a href="#" ><i class="fa-solid fa-envelope"></i>Tuerkaonline@gmail.com</a>
			<br>
			<a href="#" ><i class="fa-brands fa-whatsapp"></i>(503)7825-0098</a>
		<br>
			<p>Directamente a nuestra ferreteria, haga <a href="#"> clic aqui</a></p>
			<br>
			<p>O llene el siguiente formulario:</p>
			<br>
			</center>
			<br>
		<section class="frmContacto">
            <h4>Formulario De Contacto</h4>
            <center>
			<input class="control" type="text" name="nombre" id="nombre" placeholder="Ingrese su nombre">
			<input class="control" type="text" name="apellido" id="apellido" placeholder="Ingrese su apellido">
			<input class="control-3" type="email" name="correo" id="correo" placeholder="Ingrese su correo">
			<input class="control-4" type="text" name="numero" id="numero" placeholder="Ingrese su numero">
			<input class="control-5" type="text" name="asunto" id="asunto" placeholder="Asunto">
			<input class="control-6" type="text" name="mensaje" id="mensaje" placeholder="Mensaje">
		    <input class="boton" type="submit" value="Enviar">
		</center>
		</section>
		
			<br>
<footer>
  <!-- Footer main -->
  <section class="ft-main">
    <div class="ft-main-item">
      <h2 class="ft-title">Información para el cliente</h2>
      <ul>
        <li><a href="#">Terminos y condiciones</a></li>
        <li><a href="#">Promociones</a></li>
        <li><a href="#">Política de Cookies</a></li>
        <li><a href="#">Forma de pago</a></li>
        <li><a href="#">Centro de ayuda</a></li>
      </ul>
    </div>
    <div class="ft-main-item">
      <h2 class="ft-title">Gestión de cuenta</h2>
      <ul>
        <li><a href="#">Mi cuenta</a></li>
        <li><a href="#">Registrarme</a></li>
        <li><a href="#">Pago seguro</a></li>
        <li><a href="#">Recuperar clave</a></li>
		<li><a href="#">Cómo comprar en línea</a></li>
      </ul>
    </div>
    <div class="ft-main-item">
      <h2 class="ft-title">Sitio de interés</h2>
      <ul>
        <li><a href="#">Sucursales</a></li>
        <li><a href="#">Empleos</a></li>
        <li><a href="#">Selector de color</a></li>
		<li><a href="#">Blog</a></li>
		<li><a href="#">Epapers</a></li>
      </ul>
    </div>
    <div class="ft-main-item">
      <h2 class="ft-title">Suscríbite</h2>
      <p>Enterate de nuestras promociones.</p>
      <form>
	  
        <input type="email" name="email" placeholder="Correo Electronico">
        <input type="submit" value="Subscribirme!">
      </form>
    </div>
  </section>
  <center>
<h2 class="ft-title">Siguenos en nuestras redes sociales</h2>
</center>
  <!-- Footer social -->
  <section class="ft-social">
    <ul class="ft-social-list">
      <li><a href="https://www.facebook.com/profile.php?id=100086444436009"><i class="fab fa-facebook"></i></a></li>
      <li><a href="https://twitter.com/tuerka_tornillo"><i class="fab fa-twitter"></i></a></li>
      <li><a href="https://www.instagram.com/tuerkatornillo/"><i class="fab fa-instagram"></i></a></li>
      <li><a href="https://www.youtube.com/channel/UC95J8kLu7HgUbNpr7FSFeUw"><i class="fab fa-youtube"></i></a></li>
    </ul>
  </section>

  <!-- Footer legal -->
  <section class="ft-legal">
    <ul class="ft-legal-list">
      <li><a href="#">Terms &amp; Conditions</a></li>
      <li><a href="#">Privacy Policy</a></li>
      <li>&copy; 2019 Copyright Nowrap Inc.</li>
    </ul>
  </section>
</footer>
</body>
</html>