<?php 
require "conexion.php";
$mensaje = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $correo = $mysqli->real_escape_string($_POST['correo']);

    $sql = "SELECT * FROM usuarios WHERE correo = '$correo'";
    $resultado = $mysqli->query($sql);

    if ($resultado->num_rows > 0) {
        header("Location: restablecer.php?correo=" . urlencode($correo));
        exit;
    } else {
        $mensaje = "no_encontrado";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Recuperar Contraseña</title>
    <link rel="stylesheet" href="styles.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">

    <style>
        .title-small {
            font-size: 20px;
            text-align: center;
            margin-bottom: 20px;
            color: #fff;
            background-color: #0a0a23; /* Mismo color que el login */
            padding: 10px;
            border-radius: 10px;
            display: inline-block;
            width: 100%;
        }
		.wrapper {
            max-width: 400px;
			height: 325px;
            margin: 60px auto;
            padding: 20px;
            border-radius: 10px;
            background: #f9f9f9;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
		
        .field-icon {
            position: relative;
            display: flex;
            align-items: center;
            border: 1px solid #ccc;
            border-radius: 20px;
            padding: 10px;
            width: 100%;
        }

        .field-icon i {
            font-size: 16px;
            color: gray;
            margin-left: 10px;
        }

        .field-icon input {
            border: none;
            outline: none;
            padding-left: 15px;
            font-size: 16px;
            width: 100%;
            background: none;
        }

        .signup-link a {
            color: #0a0a23;
            text-decoration: none;
        }

        .signup-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <h2 class="title-small"><i class="fas fa-key"></i> Recuperar Contraseña</h2>
        <form method="POST">
            <div class="field-icon">
                <i class="fas fa-envelope"></i>
                <input type="email" name="correo" placeholder="Correo Electrónico" required>
            </div>
            <br>
            <div class="field">
                <input type="submit" value="Buscar">
            </div>
            <div class="signup-link">
                <a href="login.php"><i class="fas fa-arrow-left"></i> Volver al login</a>
            </div>
        </form>
    </div>

    <?php if ($mensaje === "no_encontrado"): ?>
        <script>
            Swal.fire({
                icon: 'error',
                title: 'Correo no encontrado',
                text: 'No se ha encontrado ningún usuario con ese correo.',
                confirmButtonColor: '#0a0a23'
            });
        </script>
    <?php endif; ?>
</body>
</html>

