<?php
session_start();
require "conexion.php";

if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit;
}

$id = $_SESSION['id'];
$sql = "SELECT * FROM usuarios WHERE id = $id";
$resultado = $mysqli->query($sql);
$usuario = $resultado->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Perfil del Usuario</title>
    <link rel="stylesheet" href="static/styles.css">
    <style>
        .perfil-container {
            max-width: 600px;
            margin: 50px auto;
            padding: 30px;
            border-radius: 10px;
            background-color: #f8f8f8;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            text-align: center;
        }
        .perfil-container h2 {
            margin-bottom: 20px;
        }
        .perfil-datos {
            font-size: 18px;
            margin: 10px 0;
        }
        .perfil-botones {
            margin-top: 30px;
            display: flex;
            justify-content: center;
            gap: 15px;
            flex-wrap: wrap;
        }
        .perfil-boton {
            padding: 10px 20px;
            background-color: #0a0a23;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }
        .perfil-boton:hover {
            background-color: #333;
        }
        .perfil-boton.eliminar {
            background-color: #c0392b;
        }
        .perfil-boton.eliminar:hover {
            background-color: #e74c3c;
        }
    </style>
</head>
<body>
    <div class="perfil-container">
        <h2>Perfil de <?php echo htmlspecialchars($usuario['nombre'] . ' ' . $usuario['apellido']); ?></h2>
        <p><strong>Nombre:</strong> <?php echo htmlspecialchars($usuario['nombre']); ?></p>
        <p><strong>Apellido:</strong> <?php echo htmlspecialchars($usuario['apellido']); ?></p>
        <p><strong>Teléfono:</strong> <?php echo htmlspecialchars($usuario['telefono']); ?></p>
        <p><strong>Correo:</strong> <?php echo htmlspecialchars($usuario['correo']); ?></p>
        <p><strong>Usuario:</strong> <?php echo htmlspecialchars($usuario['usuario']); ?></p>

        <div class="perfil-botones">
            <a href="index.php" class="perfil-boton">Volver al Inicio</a>
            <a href="editar_perfil.php" class="perfil-boton">Editar Perfil</a>
            <a href="eliminar_cuenta.php" class="perfil-boton eliminar">Eliminar Cuenta</a>
        </div>
    </div>
</body>
</html>
