<?php
session_start();
require 'conexion.php';

if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit;
}

$id = $_SESSION['id'];
$mensaje = "";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['eliminar'])) {
    $sql = "DELETE FROM usuarios WHERE id = $id";

    if ($mysqli->query($sql)) {
        session_destroy();
        $mensaje = "exito";
    } else {
        $mensaje = "error";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Eliminar Cuenta</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f8f8f8;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 500px;
            margin: 80px auto;
            background: #fff;
            padding: 30px;
            border-radius: 12px;
            text-align: center;
            box-shadow: 0 4px 10px rgba(0,0,0,0.15);
        }

        h2 {
            color: #e53935;
        }

        p {
            font-size: 16px;
            margin: 20px 0;
        }

        .acciones form {
            display: inline;
        }

        input[type="submit"], .cancelar-btn {
            padding: 10px 20px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-weight: bold;
        }

        input[type="submit"] {
            background-color: #d33;
            color: white;
        }

        .cancelar-btn {
            background-color: #666;
            color: white;
            text-decoration: none;
            margin-left: 10px;
            display: inline-block;
        }

        .mensaje {
            margin-top: 20px;
            color: #f44336;
            font-weight: bold;
        }
    </style>
</head>
<body>

    <div class="container">
		<center><h2>Eliminar Cuenta</h2></center>
		<form method="POST">
			<p>¿Estás seguro de que deseas eliminar tu cuenta? Esta acción no se puede deshacer.</p>
			<center>
				<input type="submit" name="eliminar" value="Eliminar cuenta">
				<a href="perfil.php" class="cancelar-btn">Cancelar</a>
			</center>
		</form>
	</div>
<?php if ($mensaje === "exito") : ?>
    <script>
        Swal.fire({
            icon: 'success',
            title: 'Cuenta eliminada',
            text: 'Tu cuenta ha sido eliminada exitosamente.',
            confirmButtonColor: '#3085d6'
        }).then(() => {
            window.location.href = 'index.php';
        });
    </script>
<?php elseif ($mensaje === "error") : ?>
    <script>
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: 'Hubo un problema al eliminar tu cuenta. Intenta nuevamente.',
            confirmButtonColor: '#d33'
        });
    </script>
<?php endif; ?>
</body>
</html>


