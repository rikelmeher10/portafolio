<?php
session_start();
require "conexion.php";

if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit;
}

$id = $_SESSION['id'];

$sql = "SELECT * FROM usuarios WHERE id = $id";
$resultado = $mysqli->query($sql);
$usuario = $resultado->fetch_assoc();

$alert = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['cancelar'])) {
        header("Location: perfil.php");
        exit;
    }

    if (isset($_POST['actualizar'])) {
        $nombre = $mysqli->real_escape_string($_POST['nombre']);
        $apellido = $mysqli->real_escape_string($_POST['apellido']);
        $telefono = $mysqli->real_escape_string($_POST['telefono']);
        $correo = $mysqli->real_escape_string($_POST['correo']);

        $sqlUpdate = "UPDATE usuarios SET 
                        nombre='$nombre', 
                        apellido='$apellido', 
                        telefono='$telefono', 
                        correo='$correo' 
                    WHERE id=$id";

        if ($mysqli->query($sqlUpdate)) {
            $_SESSION['nombre'] = $nombre;
            $_SESSION['apellido'] = $apellido;
            $alert = "success";
        } else {
            $alert = "error";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Editar Perfil</title>
    <link rel="stylesheet" href="styles.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <style>
        .form-container {
            max-width: 400px;
            margin: auto;
            padding: 25px;
            border-radius: 12px;
            background-color: #f4f4f4;
            margin-top: 40px;
        }

        input[type="text"], input[type="email"] {
            width: 100%;
            padding: 10px;
            margin: 8px 0 16px;
            border: 1px solid #ccc;
            border-radius: 6px;
        }

        .form-buttons {
            display: flex;
            gap: 10px;
        }

        .form-buttons input[type="submit"] {
            flex: 1;
            padding: 10px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-weight: bold;
            color: white;
        }

        .btn-actualizar {
            background-color: #0a0a23;
        }

        .btn-cancelar {
            background-color: #d33;
        }
    </style>
</head>
<body>

<div class="form-container">
    <center><h2>Editar Perfil</h2></center>
    <form method="POST">
        <label>Nombre:</label>
        <input type="text" name="nombre" value="<?= htmlspecialchars($usuario['nombre']) ?>" required>

        <label>Apellido:</label>
        <input type="text" name="apellido" value="<?= htmlspecialchars($usuario['apellido']) ?>" required>

        <label>Teléfono:</label>
        <input type="text" name="telefono" value="<?= htmlspecialchars($usuario['telefono']) ?>" required>

        <label>Correo:</label>
        <input type="email" name="correo" value="<?= htmlspecialchars($usuario['correo']) ?>" required>

        <div class="form-buttons">
            <input type="submit" name="actualizar" value="Actualizar" class="btn-actualizar">
            <input type="submit" name="cancelar" value="Cancelar" class="btn-cancelar">
        </div>
    </form>
</div>

<?php if ($alert === "success") : ?>
    <script>
        Swal.fire({
            icon: 'success',
            title: '¡Datos actualizados!',
            text: 'Tu perfil ha sido actualizado correctamente.',
            confirmButtonColor: '#3085d6'
        }).then(() => {
            window.location.href = 'index.php';
        });
    </script>
<?php elseif ($alert === "error") : ?>
    <script>
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: 'Hubo un problema al actualizar tus datos.',
            confirmButtonColor: '#d33'
        });
    </script>
<?php endif; ?>

</body>
</html>
