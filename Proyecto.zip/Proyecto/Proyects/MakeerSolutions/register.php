<?php
require_once 'conexion.php';
$mensaje = "";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['registro'])) {
    if ($mysqli->connect_error) {
        $mensaje = "error";
    } else {
        $nombre = $mysqli->real_escape_string($_POST['nombre']);
        $apellido = $mysqli->real_escape_string($_POST['apellido']);
        $telefono = $mysqli->real_escape_string($_POST['telefono']);
        $correo = $mysqli->real_escape_string($_POST['correo']);
        $usuario = $mysqli->real_escape_string($_POST['username']);
        $password = $_POST['password'];

        if (!filter_var($correo, FILTER_VALIDATE_EMAIL)) {
            $mensaje = "correo_invalido";
        } elseif (!preg_match("/^\d{8,9}$/", $telefono)) {
            $mensaje = "telefono_invalido";
        } elseif (!preg_match("/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/", $password)) {
            $mensaje = "password_insegura";
        } else {
            $password_hash = sha1($password);
            $check = "SELECT * FROM usuarios WHERE usuario = '$usuario'";
            $resultado = $mysqli->query($check);

            if ($resultado->num_rows > 0) {
                $mensaje = "duplicado";
            } else {
                $sql = "INSERT INTO usuarios (nombre, apellido, telefono, correo, usuario, password) 
                        VALUES ('$nombre', '$apellido', '$telefono', '$correo', '$usuario', '$password_hash')";

                if ($mysqli->query($sql) === TRUE) {
                    $mensaje = "exito";
                } else {
                    $mensaje = "error";
                }
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Registro de Usuario</title>
    <link rel="stylesheet" href="styles.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        .password-container {
            position: relative;
        }
        .eye-icon {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
        }
    </style>
</head>

<body>
    <div class="wrapper">
        <div class="title">Registro</div>
        <form method="POST" id="formRegistro">
            <div class="field">
                <input type="text" id="nombre" name="nombre" value="<?php echo isset($nombre) ? $nombre : ''; ?>" required>
                <label for="nombre">Nombre</label>
            </div>
            <div class="field">
                <input type="text" id="apellido" name="apellido" value="<?php echo isset($apellido) ? $apellido : ''; ?>" required>
                <label for="apellido">Apellido</label>
            </div>
            <div class="field">
                <input type="text" id="telefono" name="telefono" value="<?php echo isset($telefono) ? $telefono : ''; ?>" required>
                <label for="telefono">Teléfono</label>
            </div>
            <div class="field">
                <input type="email" id="correo" name="correo" value="<?php echo isset($correo) ? $correo : ''; ?>" required>
                <label for="correo">Correo</label>
            </div>
            <div class="field">
                <input type="text" id="username" name="username" value="<?php echo isset($usuario) ? $usuario : ''; ?>" required>
                <label for="username">Usuario</label>
            </div>
            <div class="field password-container">
                <input type="password" id="password" name="password" required value="<?php echo isset($password) ? $password : ''; ?>">
                <label for="password">Contraseña</label>
                <span class="eye-icon" id="togglePassword">👁️</span>
            </div>
            <div class="field">
                <input type="submit" name="registro" value="Registrar">
            </div>
            <div class="signup-link">
                ¿Ya tienes cuenta? <a href="login.php">Iniciar sesión</a>
            </div>
        </form>
    </div>

    <?php if ($mensaje == "exito"): ?>
        <script>
            Swal.fire({
                icon: 'success',
                title: '¡Éxito!',
                text: 'Datos ingresados correctamente',
                showConfirmButton: false,
                timer: 2000
            }).then(() => {
                window.location.href = 'login.php';
            });
        </script>
    <?php elseif ($mensaje == "error"): ?>
        <script>
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'Datos no válidos. Intenta nuevamente',
                confirmButtonText: 'Aceptar'
            });
        </script>
    <?php elseif ($mensaje == "duplicado"): ?>
        <script>
            Swal.fire({
                icon: 'warning',
                title: 'Usuario duplicado',
                text: 'El nombre de usuario ya está en uso. Intenta con otro.',
                confirmButtonText: 'Aceptar'
            });
        </script>
    <?php elseif ($mensaje == "password_insegura"): ?>
        <script>
            Swal.fire({
                icon: 'warning',
                title: 'Contraseña débil',
                text: 'La contraseña debe tener al menos 8 caracteres, una mayúscula, una minúscula, un número y un carácter especial.',
                confirmButtonText: 'Aceptar'
            });
        </script>
    <?php elseif ($mensaje == "correo_invalido"): ?>
        <script>
            Swal.fire({
                icon: 'warning',
                title: 'Correo inválido',
                text: 'Introduce un correo electrónico válido.',
                confirmButtonText: 'Aceptar'
            });
        </script>
    <?php elseif ($mensaje == "telefono_invalido"): ?>
        <script>
            Swal.fire({
                icon: 'warning',
                title: 'Teléfono inválido',
                text: 'El número debe contener solo dígitos y tener entre 8 y 9 cifras.',
                confirmButtonText: 'Aceptar'
            });
        </script>
    <?php endif; ?>

    <script>
        const togglePassword = document.getElementById("togglePassword");
        const passwordField = document.getElementById("password");

        togglePassword.addEventListener("click", function() {
            const type = passwordField.type === "password" ? "text" : "password";
            passwordField.type = type;
        });
    </script>
</body>
</html>


